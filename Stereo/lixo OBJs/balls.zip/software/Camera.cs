﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace balls
{
    class Camera
    {
        private int _step;
        const int TotalSteps = 240;
        const string CameraFormat = "--cam-pos-x {0} --cam-pos-y {1} --cam-pos-z {2} --cam-target-x {3} --cam-target-y {4} --cam-target-z {5}";

        const float _startPosX = 0.4184591F;
        const float _startPosY = 0.0388085F;
        const float _startPosZ = 0.2260283F;

        const float _startTargetX = 0.4711093F;
        const float _startTargetY = 0.0126644F;
        const float _startTargetZ = 0.0695818F;

        const float _finalPosX = -0.7356817F;
        const float _finalPosY = 0.2971055F;
        const float _finalPosZ = 2.1045148F;

        const float _finalTargetX = 0F;
        const float _finalTargetY = 0F;
        const float _finalTargetZ = 0F;

        public Camera(int step)
        {
            _step = step;
        }

        internal string Next()
        {
            int posStep = Math.Min(_step * 2, TotalSteps);
            int targetStep = Math.Min(_step, TotalSteps);
            float posX = _startPosX + ((_finalPosX - _startPosX) * posStep / TotalSteps);
            float posY = _startPosY + ((_finalPosY - _startPosY) * posStep / TotalSteps);
            float posZ = _startPosZ + ((_finalPosZ - _startPosZ) * posStep / TotalSteps);
            float targetX = _startTargetX + ((_finalTargetX - _startTargetX) * targetStep / TotalSteps);
            float targetY = _startTargetY + ((_finalTargetY - _startTargetY) * targetStep / TotalSteps);
            float targetZ = _startTargetZ + ((_finalTargetZ - _startTargetZ) * targetStep / TotalSteps);
            ++_step;
            return String.Format(CameraFormat, posX, posY, posZ, targetX, targetY, targetZ);
        }
    }
}
