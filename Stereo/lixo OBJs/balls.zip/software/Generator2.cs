﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace balls
{
    class Generator2
    {
        public const int Steps = 480 + 24;
        const int TotalSteps = 240;
        const int MaxBalls = 16;
        const int StepsPerBall = TotalSteps / MaxBalls;
        const double Radius = 0.51;
        int _step;

        public Generator2(int step = 0)
        {
            _step = step;
        }

        internal string Next()
        {
            int step1 = Math.Min(_step, TotalSteps - 1);
            int balls1 = Math.Min(1 + (step1 / StepsPerBall), MaxBalls);
            int frame1 = step1 % StepsPerBall; 
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < balls1; i++)
            {
                double angle = i * (Math.PI / MaxBalls);
                double x = Math.Cos(angle) * Radius;
                double y = Math.Sin(angle) * Radius;
                double scale = (i == balls1 - 1) ? Math.Min(frame1, 8) / 8.0 : 1.0;
                if (i == 0)
                {
                    builder.AppendFormat("1 0 0 {0} 0 1 0 0 0 0 1 0 ", Radius);
                }
                else
                {
                    builder.AppendFormat("{2} 0 0 {0} 0 {2} 0 {1} 0 0 {2} 0 ", x, y, scale);
                    builder.AppendFormat("{2} 0 0 {0} 0 {2} 0 {1} 0 0 {2} 0 ", x, -y, scale);
                }
            }
            if (_step >= TotalSteps)
            {
                int step2 = Math.Min(_step - TotalSteps, TotalSteps-1);
                int balls2 = Math.Min(1 + (step2 / StepsPerBall), MaxBalls);
                int frame2 = step2 % StepsPerBall;
                for (int i = 0; i < balls2; i++)
                {
                    double angle = i * (2 * Math.PI / 32);
                    double x = Math.Cos(angle) * -Radius;
                    double z = Math.Sin(angle) * -Radius;
                    double scale = (i == balls2 - 1) ? Math.Min(frame2, 8) / 8.0 : 1.0;
                    if (i == 0)
                    {
                        builder.AppendFormat("{1} 0 0 {0} 0 {1} 0 0 0 0 {1} 0 ", -Radius, scale);
                    }
                    else
                    {
                        builder.AppendFormat("{2} 0 0 {0} 0 {2} 0 0 0 0 {2} {1} ", x, z, scale);
                        builder.AppendFormat("{2} 0 0 {0} 0 {2} 0 0 0 0 {2} {1} ", x, -z, scale);
                    }
                    if (i == ((MaxBalls / 2) + 1))
                    {
                        Phase3(builder, Math.Min(step2 - (TotalSteps / 2), (TotalSteps / 2) - 1));
                    }
                }
            }
            _step += 1;
            return builder.ToString();
        }

        private void Phase3(StringBuilder builder, int step)
        {
            int balls = Math.Min(1 + (step / StepsPerBall), MaxBalls);
            int frame = step % StepsPerBall;
            for (int i = 1; i < balls; i++)
            {
                double angle = i * (2 * Math.PI / 32);
                double y = Math.Sin(angle) * Radius;
                double z = Math.Cos(angle) * Radius;
                double scale = (i == balls - 1) ? Math.Min(frame, 8) / 8.0 : 1.0;

                builder.AppendFormat("{2} 0 0 0 0 {2} 0 {0} 0 0 {2} {1} ", y, z, scale);
                builder.AppendFormat("{2} 0 0 0 0 {2} 0 {0} 0 0 {2} {1} ", y, -z, scale);
                builder.AppendFormat("{2} 0 0 0 0 {2} 0 {0} 0 0 {2} {1} ", -y, z, scale);
                builder.AppendFormat("{2} 0 0 0 0 {2} 0 {0} 0 0 {2} {1} ", -y, -z, scale);
            }
        }
    }
}
