﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace balls
{
    public partial class Form1 : Form
    {
        XmlDocument _template;
        XmlNodeList _transformNodes;

        [Flags]
        public enum EXECUTION_STATE : uint
        {
            ES_AWAYMODE_REQUIRED = 0x00000040,
            ES_CONTINUOUS = 0x80000000,
            ES_DISPLAY_REQUIRED = 0x00000002,
            ES_SYSTEM_REQUIRED = 0x00000001
            // Legacy flag, should not be used.
            // ES_USER_PRESENT = 0x00000004
        }

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        static extern EXECUTION_STATE SetThreadExecutionState(EXECUTION_STATE esFlags);

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var result = openFileDialog1.ShowDialog();
            if (result == System.Windows.Forms.DialogResult.OK)
            {
                CreateTemplate(openFileDialog1.OpenFile());
            }
        }

        private void CreateTemplate(System.IO.Stream stream)
        {
            _template = new XmlDocument();
            _template.Load(stream);
            var root = _template.DocumentElement;
            _transformNodes = root.SelectNodes("descendant::transforms");
            textBox1.Text = _transformNodes[0].InnerText;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Task.Factory.StartNew(() =>
            {
                var generator = new Generator(0);
                var generator2 = new Generator2(0);
                var camera = new Camera(0);
                int totalSteps = Generator.Steps + Generator2.Steps;
                _transformNodes[1].InnerText = generator2.Next();
                string cameraText = camera.Next();

                for (int i = 0; i < totalSteps; i++)
                {
                    _transformNodes[0].InnerText = generator.Next();
                    if (i > Generator.Steps)
                    {
                        _transformNodes[1].InnerText = generator2.Next();
                        cameraText = camera.Next();
                    }
                    var path = openFileDialog1.FileName;
                    path = Path.Combine(Path.GetDirectoryName(path), Path.GetFileNameWithoutExtension(path) + "-temp.ocs");
                    _template.Save(path);

                    var startInfo = new ProcessStartInfo();
                    startInfo.FileName = @"H:\Downloads\3D\Octane\Instancing\OctaneRender_TEST_1030_beta300_win64\octane.exe";
                    startInfo.WorkingDirectory = Path.GetDirectoryName(path);
                    startInfo.Arguments = String.Format("-t MyTarget -s 100 {0} -q -e -o D:\\Frames\\frame_{1:0000}.png {2}", cameraText, i, Path.GetFileName(path));
                    var process = Process.Start(startInfo);
                    process.WaitForExit();

                    SetThreadExecutionState(EXECUTION_STATE.ES_SYSTEM_REQUIRED | EXECUTION_STATE.ES_CONTINUOUS);
                }
                SetThreadExecutionState(EXECUTION_STATE.ES_CONTINUOUS);
            });
        }
    }
}
