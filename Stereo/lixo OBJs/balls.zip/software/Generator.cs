﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace balls
{
    class Generator
    {
        public const int Steps = 256 + 128 + 64 + 24;
        const int Fps = 32;
        const int Rate = 3;
        const int Progress = 8;
        int _step;
        int _balls = 1;
        int _ease = 0;

        public Generator(int step = 0)
        {
            _step = step;
            _balls = Math.Min(1 + (_step / Progress), 32);
            _ease = (_step / Progress >= 32) ? 0 : Math.Max(4 - (_step % Progress), 0);
            if (_step < 256) return;
            step = _step - 256;
            _phase2Balls = Math.Min(1 + (step / Progress), 16);
            _phase2Ease = (step / Progress >= 16) ? 0 : Math.Max(4 - (step % Progress), 0);
            if (_step < 384) return;
            step = _step - 384;
            _phase3Balls = Math.Min(1 + (step / Progress), 8);
            _phase3Ease = (step / Progress >= 8) ? 0 : Math.Max(4 - (step % Progress), 0);
        }

        public string Next()
        {
            int phase = _step < 256 ? 0 : (_step < 384 ? 1 : 2);
            int balls = Math.Min(1 + (_step / Progress), 32);
            if (balls > _balls) _ease = Math.Max(4 - (_step % Progress), 0);
            _balls = balls;
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < _balls; i++)
            {
                double adjust = (_balls > 1 && i == _balls - 1 && _ease > 0) ? _ease-- / 5.0 : 0.0;
                double angle = (_step - ((i * 3) - (adjust*3))) * (Math.PI / (Fps * Rate / 2.0));
                double x = Math.Cos(angle) * .05;
                double y = Math.Sin(angle) * .05;
                builder.AppendFormat("1 0 0 {0} 0 1 0 {1} 0 0 1 0 ", x, y);
                if (phase > 0)
                {
                    if (i == 0) Phase2(x, y, builder);
                }
                if (phase > 1)
                {
                    if (i == 8 || i == 24) Phase3(x, y, builder);
                }
            }
            _step += 1;
            return builder.ToString();
        }

        int _phase2Balls;
        int _phase2Ease;
        private void Phase2(double x, double y, StringBuilder builder)
        {
            int step = _step - 256;
            int balls = 1 + Math.Min((step / Progress), 16);
            if (balls > _phase2Balls) _phase2Ease = Math.Max(4 - (step % Progress), 0);
            _phase2Balls = balls;
            for (int i = 0; i < balls; i++)
            {
                double adjust = (i == balls - 1 && _phase2Ease > 0) ? _phase2Ease-- / 5.0 : 0.0;
                double angle = ((i + 1 - adjust) * 3) * (Math.PI / (Fps * Rate / 2.0));
                double d = Math.Cos(angle);
                double z = Math.Sin(angle) * .05;
                builder.AppendFormat("1 0 0 {0} 0 1 0 {1} 0 0 1 {2} ", x*d, y*d, z);
                builder.AppendFormat("1 0 0 {0} 0 1 0 {1} 0 0 1 {2} ", x*d, y*d, -z);
            }
        }

        int _phase3Balls;
        int _phase3Ease;
        private void Phase3(double x, double y, StringBuilder builder)
        {
            int step = _step - 384;
            int balls = 1 + Math.Min((step / Progress), 8);
            if (balls > _phase3Balls) _phase3Ease = Math.Max(4 - (step % Progress), 0);
            _phase3Balls = balls;
            for (int i = 0; i < balls; i++)
            {
                double adjust = (i == balls - 1 && _phase3Ease > 0) ? _phase3Ease-- / 5.0 : 0.0;
                double angle = ((i + 1 - adjust) * 3) * (Math.PI / (Fps * Rate / 2.0));
                double d = Math.Cos(angle);
                double z = Math.Sin(angle) * .05;
                builder.AppendFormat("1 0 0 {0} 0 1 0 {1} 0 0 1 {2} ", x * d, y * d, z);
                builder.AppendFormat("1 0 0 {0} 0 1 0 {1} 0 0 1 {2} ", x * d, y * d, -z);
            }
        }
    }
}
