This is a model for the Galileo 7 from Star Trek the original series. It was done mostly free hand, without following references. It is in .obj and .3ds formats. A .bmp verison of the map template is include. The texture map could use some work. I did this mostly for fun and it proved to be educational as far as creating the UVs and texture mapping. Perhaps one day I'll do another with that more closely follows the reference material. This one could be used for background scenes.

Enjoy.
